# DistributionViewer

It is a online tool to plot pdf of different distirbutions with adjustable parameters.

___

## Authors
Yixin Chen, Minsheng Hao

## Package
ggplot2, Shiny

## email
chenyx19@mails.tsinghua.edu.cn